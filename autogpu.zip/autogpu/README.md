# AutoGPU ⭐⭐⭐⭐⭐

Detecta automáticamente CPU, GPU o TPU disponibles y ejecuta tu código en el
hardware más rápido posible, sin que tengas que escribir `if torch.cuda.is_available()`
nunca más.

## Instalación

```bash
pip install -e .
```

(Opcionalmente instala `torch` y/o `tensorflow` para que AutoGPU pueda
detectar y usar GPU/TPU reales.)

## Uso rápido

```python
from autogpu import AutoGPU

device = AutoGPU.detect(verbose=True)
print(device)  # "tpu", "cuda", "mps" o "cpu"
```

### Mover un modelo o tensor automáticamente

```python
import torch
from autogpu import AutoGPU

modelo = torch.nn.Linear(10, 2)
modelo = AutoGPU.to_device(modelo)
```

### Como decorador

```python
from autogpu import AutoGPU

@AutoGPU.run(verbose=True)
def entrenar(datos, device=None):
    print(f"Entrenando en: {device}")

entrenar(datos=[1, 2, 3])
```

### Resumen del hardware

```python
from autogpu import AutoGPU
print(AutoGPU.summary())
```

## Orden de prioridad de detección

1. **TPU** (vía `torch_xla` o TensorFlow Cloud TPU)
2. **GPU NVIDIA/AMD** (CUDA, vía PyTorch o TensorFlow)
3. **GPU Apple Silicon** (Metal / MPS)
4. **CPU** (si no se detecta ningún acelerador)

## Licencia

MIT
