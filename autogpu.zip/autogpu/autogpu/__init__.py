"""
AutoGPU
=======
Detecta automáticamente CPU, GPU o TPU disponibles y ejecuta el código
en el hardware más rápido posible.

Uso básico:
    from autogpu import AutoGPU

    device = AutoGPU.detect()
    print(device)  # "cuda", "tpu", "mps" o "cpu"

    # Como decorador
    @AutoGPU.run()
    def entrena_modelo(x):
        ...

    # Mover tensores/objetos automáticamente
    modelo = AutoGPU.to_device(modelo)
"""

from .core import AutoGPU

__all__ = ["AutoGPU"]
__version__ = "0.1.0"
