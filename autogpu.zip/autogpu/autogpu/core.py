"""Lógica central de detección y ejecución de hardware."""

import functools
import importlib
import os
import platform
import subprocess


class AutoGPU:
    """Detecta el mejor hardware disponible (TPU > GPU > MPS > CPU)
    y ofrece utilidades para ejecutar código allí automáticamente."""

    _cached_device = None
    _cached_backend = None  # "torch", "tensorflow" o None

    # ------------------------------------------------------------------ #
    # Detección
    # ------------------------------------------------------------------ #
    @classmethod
    def detect(cls, verbose: bool = False, force: bool = False) -> str:
        """Devuelve el mejor dispositivo disponible: 'tpu', 'cuda',
        'mps' o 'cpu'. El resultado se cachea salvo que force=True."""
        if cls._cached_device is not None and not force:
            return cls._cached_device

        device, backend, info = cls._scan_hardware()
        cls._cached_device = device
        cls._cached_backend = backend

        if verbose:
            print(f"[AutoGPU] Backend: {backend or 'ninguno detectado'}")
            print(f"[AutoGPU] Dispositivo seleccionado: {device}")
            print(f"[AutoGPU] Detalle: {info}")

        return device

    @classmethod
    def _scan_hardware(cls):
        """Recorre TPU -> GPU (CUDA) -> GPU (Apple MPS) -> CPU."""

        # 1. TPU (vía torch_xla o tensorflow)
        tpu_info = cls._check_tpu()
        if tpu_info:
            return "tpu", tpu_info["backend"], tpu_info["detail"]

        # 2. GPU NVIDIA / AMD (vía PyTorch)
        if cls._is_installed("torch"):
            import torch

            if torch.cuda.is_available():
                name = torch.cuda.get_device_name(0)
                count = torch.cuda.device_count()
                return "cuda", "torch", f"{count} GPU(s) CUDA: {name}"

            # Apple Silicon (Metal Performance Shaders)
            if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
                return "mps", "torch", "GPU Apple Silicon (MPS)"

        # 3. GPU vía TensorFlow (si no hay torch o no detectó nada)
        if cls._is_installed("tensorflow"):
            import tensorflow as tf

            gpus = tf.config.list_physical_devices("GPU")
            if gpus:
                return "cuda", "tensorflow", f"{len(gpus)} GPU(s) detectada(s) por TensorFlow"

        # 4. Verificación de bajo nivel con nvidia-smi (por si no hay
        #    torch/tensorflow instalados pero sí drivers NVIDIA)
        if cls._nvidia_smi_available():
            return "cuda", None, "GPU NVIDIA detectada vía nvidia-smi (instala torch o tensorflow para usarla)"

        # 5. CPU como último recurso
        return "cpu", None, f"{platform.processor() or platform.machine()} ({os.cpu_count()} núcleos)"

    @staticmethod
    def _check_tpu():
        # PyTorch/XLA (Google Colab / Cloud TPU)
        if AutoGPU._is_installed("torch_xla"):
            try:
                import torch_xla.core.xla_model as xm

                dev = xm.xla_device()
                return {"backend": "torch", "detail": f"TPU vía torch_xla: {dev}"}
            except Exception:
                pass

        # TensorFlow TPU
        if AutoGPU._is_installed("tensorflow"):
            try:
                import tensorflow as tf

                resolver = tf.distribute.cluster_resolver.TPUClusterResolver()
                tf.config.experimental_connect_to_cluster(resolver)
                tf.tpu.experimental.initialize_tpu_system(resolver)
                return {"backend": "tensorflow", "detail": "TPU vía TensorFlow"}
            except Exception:
                pass

        return None

    @staticmethod
    def _is_installed(module_name: str) -> bool:
        try:
            importlib.import_module(module_name)
            return True
        except Exception:
            return False

    @staticmethod
    def _nvidia_smi_available() -> bool:
        try:
            subprocess.run(
                ["nvidia-smi"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=3,
                check=True,
            )
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------ #
    # Utilidades de ejecución
    # ------------------------------------------------------------------ #
    @classmethod
    def to_device(cls, obj, verbose: bool = False):
        """Mueve un tensor/modelo de PyTorch (o lista/tupla de ellos)
        al mejor dispositivo disponible. Si no es un objeto de torch,
        lo devuelve sin modificar."""
        device = cls.detect(verbose=verbose)

        if cls._is_installed("torch"):
            import torch

            torch_device = "cpu" if device == "tpu" and not cls._is_installed("torch_xla") else device
            if device == "tpu" and cls._is_installed("torch_xla"):
                import torch_xla.core.xla_model as xm
                torch_device = xm.xla_device()

            if isinstance(obj, (list, tuple)):
                return type(obj)(cls.to_device(o, verbose=False) for o in obj)
            if hasattr(obj, "to") and isinstance(obj, (torch.nn.Module, torch.Tensor)):
                return obj.to(torch_device)

        return obj

    @classmethod
    def run(cls, verbose: bool = False):
        """Decorador que detecta el hardware antes de ejecutar la función
        e inyecta el dispositivo como kwarg `device` si la función lo acepta."""

        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                device = cls.detect(verbose=verbose)
                if "device" in func.__code__.co_varnames:
                    kwargs.setdefault("device", device)
                return func(*args, **kwargs)

            return wrapper

        return decorator

    @classmethod
    def summary(cls) -> str:
        """Devuelve un resumen legible del hardware detectado."""
        device, backend, info = cls._scan_hardware()
        return (
            f"Dispositivo: {device}\n"
            f"Backend: {backend or 'N/A'}\n"
            f"Detalle: {info}\n"
            f"Sistema: {platform.system()} {platform.release()} ({platform.machine()})"
        )


if __name__ == "__main__":
    print(AutoGPU.summary())
