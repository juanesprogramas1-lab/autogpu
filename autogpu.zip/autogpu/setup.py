from setuptools import setup, find_packages

setup(
    name="autogpu",
    version="0.1.0",
    description="Detecta automáticamente CPU, GPU o TPU y ejecuta el código en el hardware más rápido disponible.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    license="MIT",
    extras_require={
        "torch": ["torch"],
        "tensorflow": ["tensorflow"],
    },
)
